#include "Investment.h"
// Базовая реализация отсутствует.
